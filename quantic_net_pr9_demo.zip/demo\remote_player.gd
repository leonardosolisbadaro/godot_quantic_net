extends Node3D

var owner_id := 0

func _physics_process(_delta: float) -> void:
	if owner_id == 0: return
	
	# Fetch interpolated state directly from QuanticNet domain
	var state = QuanticNet.remote_state(owner_id)
	
	if not state.is_empty():
		# Apply smoothly interpolated remote state to the visual node
		global_position = state["pos"]
		rotation = state["rot"]

func _ready() -> void:
	# Change color for remote players to differentiate
	if has_node("MeshInstance3D"):
		var mat = StandardMaterial3D.new()
		mat.albedo_color = Color.RED
		$MeshInstance3D.material_override = mat
