extends Node

@onready var host_btn: Button = $UI/VBoxContainer/HostButton
@onready var join_btn: Button = $UI/VBoxContainer/JoinButton
@onready var world: Node3D = $World

const PORT = 9999
const SECRET = "qnet_demo_secret"
var _players := {}

func _ready() -> void:
	host_btn.pressed.connect(_on_host_pressed)
	join_btn.pressed.connect(_on_join_pressed)
	
	QuanticNet.peer_joined.connect(_on_peer_joined)
	QuanticNet.peer_left.connect(_on_peer_left)

func _on_host_pressed() -> void:
	# Use dummy development certificates for demo (fallback)
	var key = CryptoKey.new()
	var cert = X509Certificate.new()
	var err = QuanticNet.host(PORT, SECRET, key, cert)
	if err == OK:
		host_btn.disabled = true
		join_btn.disabled = true
		_spawn_local_player(1)
	else:
		print("Failed to host: ", err)

func _on_join_pressed() -> void:
	var cert = X509Certificate.new()
	var err = QuanticNet.join("127.0.0.1", PORT, SECRET, cert)
	if err == OK:
		host_btn.disabled = true
		join_btn.disabled = true
	else:
		print("Failed to join: ", err)

func _on_peer_joined(id: int) -> void:
	print("Peer joined: ", id)
	if id == multiplayer.get_unique_id():
		_spawn_local_player(id)
	else:
		_spawn_remote_player(id)

func _on_peer_left(id: int) -> void:
	print("Peer left: ", id)
	if _players.has(id):
		_players[id].queue_free()
		_players.erase(id)

func _spawn_local_player(id: int) -> void:
	if _players.has(id): return
	var p = preload("res://demo/player.tscn").instantiate()
	p.name = str(id)
	# Spawns around origin
	p.position = Vector3(randf_range(-2, 2), 1, randf_range(-2, 2))
	world.add_child(p)
	_players[id] = p

func _spawn_remote_player(id: int) -> void:
	if _players.has(id): return
	var p = preload("res://demo/remote_player.tscn").instantiate()
	p.name = str(id)
	p.owner_id = id
	world.add_child(p)
	_players[id] = p
