extends CharacterBody3D

const SPEED = 5.0
const ROTATION_SPEED = 3.0

var _custom_id := 0

func _physics_process(delta: float) -> void:
	if not multiplayer.is_server():
		var move_dir = Vector2.ZERO
		var rot_delta = 0.0
		
		if Input.is_action_pressed("ui_up"):
			move_dir.y += 1
		if Input.is_action_pressed("ui_down"):
			move_dir.y -= 1
		if Input.is_action_pressed("ui_left"):
			rot_delta += ROTATION_SPEED * delta
		if Input.is_action_pressed("ui_right"):
			rot_delta -= ROTATION_SPEED * delta
		
		# Rotate around Y axis
		rotation.y += rot_delta
		
		# Move forward/backward based on facing direction
		var forward = -transform.basis.z
		var velocity_3d = forward * move_dir.y * SPEED
		
		velocity = velocity_3d
		move_and_slide()
		
		# Submit to QuanticNet (will rate-limit to 20Hz internally and record input for prediction)
		QuanticNet.submit_state(global_position, rotation, _custom_id, delta)

func _ready() -> void:
	# Only listen to snapbacks for our own character
	QuanticNet.snapback_received.connect(_on_snapback_received)
	
	# Add a camera so we can see
	var cam = Camera3D.new()
	cam.position = Vector3(0, 3, 5)
	cam.rotation_degrees = Vector3(-20, 0, 0)
	add_child(cam)

func _on_snapback_received(seq: int, srv_pos: Vector3, srv_rot: Vector3, reason: int, replay_inputs: Array) -> void:
	# Server corrected our position
	global_position = srv_pos
	rotation = srv_rot
	
	# Reapply pending inputs that happened after the server's confirmed sequence
	for input in replay_inputs:
		# Basic kinematic replay:
		rotation.y += input["rot_delta"]
		
		var forward = -transform.basis.z
		var move_dir_y = input["move"].y
		velocity = forward * move_dir_y * SPEED
		
		# Need to fake move_and_slide with delta, but move_and_slide uses physics delta directly.
		# For simple demo, manual integration is fine to illustrate.
		global_position += velocity * input["dt"]
